<?php
session_start();
require("../db.php");

$mail = $_SESSION["nemail"];
$code = $_SESSION["code"];
$user_code = $_GET["code"];

if ($code == $user_code) {
    $stmt = $pdo->prepare("UPDATE users SET email = :mail WHERE login = :login");
    $stmt->execute(["mail"=>$mail,"login"=>$_SESSION["user"]]);
    $_SESSION["error"] = "Код введен верно! Почта изменена.";
    header("Location: /profile");
} else {
    $_SESSION["error"] = "Код введен не верно!";
    header("Location: /profile");
}