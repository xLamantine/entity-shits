<?php session_start(); 
require("../db.php");
if ($_SESSION["user"] && $_SESSION["password"]) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE `login` = :login and `pass` = :pass");
    $stmt->execute(["pass"=>$_SESSION["password"],"login"=>$_SESSION["user"]]);
    $r = $stmt->rowCount();
    $fe = $stmt->fetch();
    if ($r < 1) {
        $_SESSION["error"] = "Сессия неактивна! Перезайдите в аккаунт!";
        header("Location: /");
        unset($_SESSION["user"]);
        unset($_SESSION["password"]);
    } 
} else {
    header("Location: /login");
}
?>
<!DOCTYPE html>
<html lang="ru"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta charset="UTF-8">
    <title>
                entity-cheats.com - Приватные читы для RUST и DBD ⚙    </title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="/fonts/main.css">
	<meta name="enot" content="5141599653309g2MfYST02QUqPha-dOHpLpVXQr_aNuvX">
    <meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" name="og:title">
	<meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" name="vk:title">
	<meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" itemprop="name">
	<meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" name="twitter:title">
	<meta content="раст скачивать чит,раст го скин,skin changer,чит раст,чит го,чит раст го,читы на раст,читы на растго,читы на cs go,вх раст го,банихоп в раст,аим в раст,легит,легит читы,легит кфг,качать легит,рейдж для раст,искван,EntityCheats,читы EntityCheats,EntityCheats чит раст,EntityCheats скачать,EntityCheats чит кряк,system bot,EntityCheats crack" name="keywords">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="description" property="description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="og:description" property="og:description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." itemprop="description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="vk:description" property="vk:description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="twitter:description" property="twitter:description">
    <style type="text/css">* { font-display: swap; font-family: 'Acrom';} </style>
	
<!--    <link rel="stylesheet" href="/min/?g=css&v=2.0">-->
    <link rel="stylesheet" href="../loxa_files/bootstrap.css">
    <link rel="stylesheet" href="../loxa_files/main_1.css">
    <link rel="stylesheet" href="../loxa_files/font.css">
    <link rel="stylesheet" href="../loxa_files/all.css">
    <script async="" src="../loxa_files/tag.js"></script><script src="../loxa_files/jquery-3.js"></script>

    <link rel="apple-touch-icon" type="image/vnd.microsoft.icon" sizes="76x76" href="/favicon.ico">
    <link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
	<link rel="shortcut icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="76x76" href="/favicon.ico">
	<link rel="icon" type="image/x-icon" href="/favicon.ico">
	<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
    <meta content="/favicon.ico" name="og:image" property="og:image">
    <meta content="/favicon.ico" name="vk:image" property="vk:image">
    <meta content="/favicon.ico" name="twitter:image" property="twitter:image">
    <meta content="https://entity-cheats.com" name="og:url">
    <meta content="https://entity-cheats.com" name="vk:url">
    <meta content="https://entity-cheats.com" name="twitter:url">
    <meta property="og:image:width" content="16">
    <meta property="og:image:height" content="16">
    <meta name="yandex-verification" content="c070d3ca3abf405b">
    <link rel="stylesheet" href="../loxa_files/slick.css">
<link rel="stylesheet" href="../loxa_files/slick-theme.css">
<style>
    input[type="text"] {
    background: black;
    color: white;
    text-align: center;
    margin: 10px 5px;
    width: 250px;
    outline: none;
    border-radius: 5px;
    border: 1px solid #a042f1;
    }
</style>
</head>
<body>
<header class="navbar navbar-light navbar-expand-lg mb-lg-5">
	<a class="mr-0 mr-lg-5" href="/">
		<a onclick="location.href='/'" id="logotypeahahh" style="margin-top: 10px; font-size: 30px; margin-left: -33px; margin-right: 30px;">Entity<span style="color: #a042f1;">Cheats</span></a>	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div  style="margin-top: 15px;" class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav ml-lg-6">
			<li class="nav-item">
				<a class="nav-link" href="/forum">Форум</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="/status">Статусы читов</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="/shop">Магазин</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="https://discord.gg/fWZkfwpjhJ">Поддержка</a>
			</li>
			<li class="mo nav-item">
				<a class="nav-link" href="/tickets"><?php echo $_SESSION["user"]; ?></a>
			</li>

			<li class="do nav-item">
				<a class="nav-link" style="border: 1px solid white; border-radius: 10px; padding: 3px 10px; position: absolute; right: 10px; top: 25px;" href="/profile"><?php if ($_SESSION["user"]) { echo $_SESSION["user"]; } else { echo "Войти в аккаунт"; } ?></a>
			</li>
		</ul>
	</div>
	<div class="square-change"></div>
</header>


<div class="container">
    <div class="left_menu col-xs-12 col-lg-3">
        <p id="tgeneral">Основная информация</p>
        <p id="tbuyes">Покупки</p>
        <p id="tsubs">Активные подписки</p>
        <p id="tpromo">Использовать ключ</p>
        <p id="tpass">Изменить пароль</p>

    </div>
    <div id="general" class="right_menu col-lg-8">
        <h3>Аккаунт <?php echo $_SESSION["user"];?></h3>
        <p>Email: <?php echo $fe["email"];?></p>
        <div onclick="location.href='./change_mail.php'" class="btn btn-primary">Сменить почту</div>
        <div onclick="location.href='./logout.php'" class="btn btn-danger">Выйти</div>
    </div>
    <div id="buyes" class="hidden right_menu col-lg-8">
        <h3>Покупки <?php echo $_SESSION["user"];?></h3>
        <div class="table">
            <div class="div">
                <p id="id">#</p>
                <p id="tovar">Ключ</p>
                <p id="key">Продукт</p>
                <p id="stamp">Дней</p>
            </div>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM buyes WHERE login = :login");
            $stmt->execute(["login"=>$_SESSION["user"]]);
            while($f = $stmt->fetch()) {    
            ?>
            <div class="div">
                <p id="id"><?php echo $f["id"];?></p>
                <p style="font-size: 12px;" id="tovar"><?php echo $f["product_key"];?></p>
                <p id="key"><?php echo $f["name"];?></p>
                <p id="stamp"><?php echo $f["days"];?></p>
            </div>
            <?php }?>
        </div>
        <p></p>
    </div>
    <div id="subs" class="hidden right_menu col-lg-8">
        <h3>Подписки <?php echo $_SESSION["user"];?></h3>
        <div class="table" >
            <div class="div" >
                <p id="name">Название</p>
                <p id="start">Начало подписки</p>
                <p id="end">Конец подписки</p>
                <button disabled class="btn btn-success" id="btn">Где вы играете?</button>
            </div>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM subs WHERE user = :login and `status` = 1");
            $stmt->execute(["login"=>$_SESSION["user"]]);
            while($f = $stmt->fetch()) {
                $date = $f["end"];
                
//                \DateTime::createFromFormat('Y-m-d H:i:s',$date) < new \DateTime()
                if(strtotime($date) < strtotime(date('Y-m-d H:i:s'))){
                    $stmt = $pdo->prepare("UPDATE subs SET status = 0 WHERE id = :id");
                    $stmt->execute(["id"=>$f["id"]]);
                } else {
            ?>

            <div class="div">
                <p id="name"><?php if($f["product"] == "EntityDBD") { echo "EntityDBD "; } else { echo "EntityRust"; }?></p>
                <p id="start"><?php echo $f["start"];?></p>
                <p id="end"><?php echo $f["end"]; ?></p>

                <a id="btn" class="btn btn-success" target="_blank" href='<?php if($f["product"] == "EntityDBD") { echo "https://vk.cc/caNscx"; } else { echo ""; }?>'>Steam</a>
                <a id="btn" class="btn btn-success" target="_blank" href='<?php if($f["product"] == "EntityDBD") { echo "https://vk.cc/cbQqxT"; } else { echo ""; }?>'>EGS</a>

            </div>
            <?php }} ?>
        </div>
    </div>
    <div id="promo" class="hidden right_menu col-lg-8">
        <h3>Использовать ключ</h3>
        <form action="./submit-promo.php" method="POST">
            <div class="table">
                <input type="text" id="key" placeholder="Ключ активации" name="promo">
                <input type="submit" class="btn btn-success" value="Активировать">
            </div>
        </form>
    </div>
    <div id="change_pass" class="hidden right_menu col-lg-8">
        <h3>Изменить пароль</h3>
        <form action="./change_pass.php" action="POST">
            <div class="table">
                <input type="text" placeholder="Старый пароль" name="old">
                <input type="text" placeholder="Новый пароль" name="new">
                <input type="submit" class="btn btn-success" value="Изменить">
            </div>
        </form>
    </div>
</div>






<script src="/../loxa_files/popper.js"></script>
    <script src="/../loxa_files/bootstrap.js"></script>
	<script src="/../loxa_files/perfect-scrollbar.js"></script>
	<script src="/../loxa_files/custom.js"></script>
	<script src="/../loxa_files/slick.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js"></script>
<script>
    $("#tgeneral").on("click",function(){
        $("#general").show();
        $("#buyes, #subs, #promo, #change_pass").hide();
    });
    $("#tbuyes").on("click",function(){
        $("#buyes").show();
        $("#general, #subs, #promo, #change_pass").hide();
    });
    $("#tsubs").on("click",function(){
        $("#subs").show();
        $("#general, #buyes, #promo, #change_pass").hide();
    });
    $("#tpromo").on("click",function(){
        $("#promo").show();
        $("#general, #subs, #buyes, #change_pass").hide();
    });
    $("#tpass").on("click",function(){
        $("#change_pass").show();
        $("#general, #buyes, #promo, #subs").hide();
    });
	<?php 
	if ($_SESSION["error"]) {
	?>
    $.notify("<?php echo $_SESSION["error"];?>","error");
	<?php unset($_SESSION["error"]); } ?>
    var splide = null;
    $(document).ready(function() {
        $( '.splide').slick({
            centerMode: true,
            centerPadding: '60px',
            slidesToShow: 3,
            responsive: [
                {
                    breakpoint: 1200,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '60px',
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70px',
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70x',
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70x',
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 360,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70x',
                        slidesToShow: 1
                    }
                },
            ],
            infinite: true,
			dots: true,
            autoplay: true,
            autoplaySpeed: 2500,
		});
    });
</script>
<script>
	$('.navbar-toggler').on("click",function(){
		$("#logotypeahahh").toggle();
	})
</script>
</body>
</html>