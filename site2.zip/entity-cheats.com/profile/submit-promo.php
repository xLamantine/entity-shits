<?php   
session_start();
require("../db.php");
$key = $_POST["promo"];
$stmt = $pdo->prepare("SELECT * FROM _key WHERE product_key = :key");
$stmt->execute(["key"=>$key]);
$f = $stmt->fetch();
$days = $f["days"];
$pr = $f["product"];
$ac = $f["activated"];

$r = $stmt->rowCount();
$user = $_SESSION["user"];
$start = $today = date("Y-m-d H:i:s");
$end = date('Y-m-d H:i:s', strtotime($Date. ' + '.$days.' days'));
if ($r > 0 and $ac == 0) {
    $stmt = $pdo->prepare("UPDATE _key SET `activated` = 1,`activator`= :user WHERE product_key = :key");
    $stmt->execute(["user"=>$user,"key"=>$key]);
    $stmt = $pdo->prepare("INSERT INTO subs (`product`,`user`,`start`,`end`,`status`,`product_key`) VALUES (:pr,:user,:start,:end,:sts,:key)");
    $stmt->execute(["pr"=>$pr,"user"=>$user,"start"=>$start,"end"=>$end,"sts"=>1,"key"=>$key]);
    $_SESSION["error"] = "Ключ активирован!";
} else {
    $_SESSION["error"] = "Ключ не найден!";
}
header("location: /profile");