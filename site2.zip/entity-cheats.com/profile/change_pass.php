<?php
session_start();
require("../db.php");
$stmt = $pdo->prepare("SELECT * FROM users WHERE login = :login AND pass = :pass");
$stmt->execute(["login"=>$_SESSION["user"],"pass"=>$_GET["old"]]);
$r = $stmt->rowCount();
if ($r > 0) {
    $stmt = $pdo->prepare("UPDATE users SET pass = :pass WHERE login = :login");
    $stmt->execute(["login"=>$_SESSION["user"],"pass"=>$_GET["new"]]);
    $_SESSION["error"] = "Пароль успешно изменен!";
    $_SESSION["pass"] = $_GET["new"];
} else {
    $_SESSION["error"] = "Старый пароль введен не верно!";
}
header("Location: /profile");