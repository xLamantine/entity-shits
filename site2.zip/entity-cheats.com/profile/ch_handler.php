<?php
session_start();
require("../db.php");
$code = random_int(1111,9999);
$_SESSION["code"] = $code;
$new = $_GET["new_email"];
$_SESSION["nemail"] = $new;
$pass = $_GET["password"];
$stmt = $pdo->prepare("SELECT * FROM users WHERE login = :login and pass = :pass");
$stmt->execute(["login"=>$_SESSION["user"],"pass"=>$pass]);
if ($stmt->rowCount() > 0) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :mail");
    $stmt->execute(["mail"=>$new]);
    $r = $stmt->rowCount();
    if ($r > 0) {
        $_SESSION["error"] = "Почта уже используется";
        header("Location: /profile");
    } else {
    mail($new,"Изменение email для ваше аккаунта на EntityCheats","Код: ".$code);
    header("Location: ./change_mail.php?activation=1");
}
} else {
    $_SESSION["error"] = "Пароль указан не верно.";
    header("Location: /profile");
}