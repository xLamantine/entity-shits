<?php
session_start();

error_reporting(E_ALL);
ini_set('display_startup_errors', 1);
ini_set('display_errors', '1'); 

require("../db.php");
$login = $_POST["login"];
$pass = $_POST["password"];
$email = $_POST["email"];

$stmt = $pdo->prepare("SELECT * FROM users WHERE `login` = :login OR `email` = :email");
$stmt->execute(["login"=>$login,"email"=>$email]);
$r = $stmt->rowCount();
if ($r > 0) {
    $_SESSION["error"] = "Логин или почта уже используется";
} else {
    if (strlen($pass) > 7) {
        if ($pass == $_POST["r_password"]) {
        $stmt = $pdo->prepare("INSERT INTO users (`login`,`pass`,`email`) VALUES (:login,:pass,:email)");
        $stmt->execute(["login"=>$login,"pass"=>$pass,"email"=>$email]);
        $_SESSION["user"] = $login;
        $_SESSION["password"] = $pass;
    } else {
        $_SESSION["error"] = "Пароли не совпадает!";
    }
    } else {
        $_SESSION["error"] = "Пароль должен быть от 8 символов!";
    }
}

header("location: /");