<?php
session_start();

error_reporting(E_ALL);
ini_set('display_startup_errors', 1);
ini_set('display_errors', '1'); 

require("../db.php");
$login = $_POST["login"];
$pass = $_POST["password"];

$stmt = $pdo->prepare("SELECT * FROM users WHERE `login` = :login AND `pass` = :pass");
$stmt->execute(["login"=>$login,"pass"=>$pass]);
$r = $stmt->rowCount();

if ($r > 0) {
    $_SESSION["user"] = $login;
    $_SESSION["password"] = $pass;
    header("location: /profile");
    echo 1;
} else {
    $_SESSION["error"] = "Логин или пароль введен не верно!";
    header("location: /");
    echo 0;
}
