<?php session_start(); 
require("../db.php");
if ($_SESSION["user"] && $_SESSION["password"]) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE `login` = :login and `pass` = :pass");
    $stmt->execute(["pass"=>$_SESSION["password"],"login"=>$_SESSION["user"]]);
    $r = $stmt->rowCount();
    if ($r < 1) {
        $_SESSION["error"] = "Сессия неактивна! Перезайдите в аккаунт!";
        header("Location: /");
    } else {
        header("Location: /profile");
        die();
    }
}

?>
<!DOCTYPE html>
<html lang="ru"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta charset="UTF-8">
    <title>
                entity-cheats.com - Приватные читы для RUST и DBD ⚙    </title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="/fonts/main.css">
	<meta name="enot" content="5141599653309g2MfYST02QUqPha-dOHpLpVXQr_aNuvX">
    <meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" name="og:title">
	<meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" name="vk:title">
	<meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" itemprop="name">
	<meta content="entity-cheats.com - Приватные читы для RUST и DBD ⚙" name="twitter:title">
	<meta content="раст скачивать чит,раст го скин,skin changer,чит раст,чит го,чит раст го,читы на раст,читы на растго,читы на cs go,вх раст го,банихоп в раст,аим в раст,легит,легит читы,легит кфг,качать легит,рейдж для раст,искван,EntityCheats,читы EntityCheats,EntityCheats чит раст,EntityCheats скачать,EntityCheats чит кряк,system bot,EntityCheats crack" name="keywords">
	
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="description" property="description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="og:description" property="og:description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." itemprop="description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="vk:description" property="vk:description">
	<meta content="EntityCheats - великолепно сбалансированный приватный чит, идеальное соотношение трезвой цены и хорошего качества! Чит можно настроить полностью под себя, в нем присутствуют все необходимые и проработанные функции для любого стиля игры." name="twitter:description" property="twitter:description">
    <style type="text/css">* { font-display: swap; font-family: 'Acrom';} </style>
	
<!--    <link rel="stylesheet" href="/min/?g=css&v=2.0">-->
    <link rel="stylesheet" href="../loxa_files/bootstrap.css">
    <link rel="stylesheet" href="../loxa_files/main_1.css">
    <link rel="stylesheet" href="../loxa_files/font.css">
    <link rel="stylesheet" href="../loxa_files/all.css">
    <script async="" src="../loxa_files/tag.js"></script><script src="../loxa_files/jquery-3.js"></script>

    <link rel="apple-touch-icon" type="image/vnd.microsoft.icon" sizes="76x76" href="/favicon.ico">
    <link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
	<link rel="shortcut icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="76x76" href="/favicon.ico">
	<link rel="icon" type="image/x-icon" href="/favicon.ico">
	<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
    <meta content="/favicon.ico" name="og:image" property="og:image">
    <meta content="/favicon.ico" name="vk:image" property="vk:image">
    <meta content="/favicon.ico" name="twitter:image" property="twitter:image">
    <meta content="https://entity-cheats.com" name="og:url">
    <meta content="https://entity-cheats.com" name="vk:url">
    <meta content="https://entity-cheats.com" name="twitter:url">
    <meta property="og:image:width" content="16">
    <meta property="og:image:height" content="16">
    <meta name="yandex-verification" content="c070d3ca3abf405b">
    <link rel="stylesheet" href="../loxa_files/slick.css">
<link rel="stylesheet" href="../loxa_files/slick-theme.css">
</head>
<body>
<header class="navbar navbar-light navbar-expand-lg mb-lg-5">
<div class="container">
	<a class="mr-0 mr-lg-5" href="/">
		<a onclick="location.href='/'" id="logotypeahahh" style="margin-top: 10px; font-size: 30px; margin-left: -33px; margin-right: 30px;">Entity<span style="color: #a042f1;">Cheats</span></a>	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div  style="margin-top: 15px;" class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav ml-lg-6">
			<li class="nav-item">
				<a class="nav-link" href="/forum">Форум</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="/status">Статусы читов</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="/shop">Магазин</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="/tickets">Поддержка</a>
			</li>
		</ul>
	</div>
	<div class="square-change"></div>
    </div>
</header>




<div class="reg_form col-lg-3">
    <h2>Вход</h2>
    <form method="POST" action="./handler.php">
        <input name="login" type="text" placeholder="Логин">
        <input name="password" type="password" placeholder="Пароль">
        <input type="submit" value="Войти" placeholder="Почта">
    </form>
    <p style="text-align: center;">Еще нету аккаунта? <a href="/register">Регистрация</a></p>

</div>










<script src="/../loxa_files/popper.js"></script>
    <script src="/../loxa_files/bootstrap.js"></script>
	<script src="/../loxa_files/perfect-scrollbar.js"></script>
	<script src="/../loxa_files/custom.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js"></script>
<script>
	<?php 
	if ($_SESSION["error"]) {
	?>
    $.notify("<?php echo $_SESSION["error"];?>","error");
	<?php unset($_SESSION["error"]); } ?>
    var splide = null;
    $(document).ready(function() {
        $( '.splide').slick({
            centerMode: true,
            centerPadding: '60px',
            slidesToShow: 3,
            responsive: [
                {
                    breakpoint: 1200,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '60px',
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70px',
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70x',
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70x',
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 360,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '70x',
                        slidesToShow: 1
                    }
                },
            ],
            infinite: true,
			dots: true,
            autoplay: true,
            autoplaySpeed: 2500,
		});
    });
</script>
<script>
	$('.navbar-toggler').on("click",function(){
		$("#logotypeahahh").toggle();
	})
</script>
</body>
</html>